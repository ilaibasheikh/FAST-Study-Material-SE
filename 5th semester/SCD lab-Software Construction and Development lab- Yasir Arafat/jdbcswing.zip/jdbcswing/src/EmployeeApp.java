import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class EmployeeApp extends JFrame {
    private JTextField idField, nameField, departmentField;
    private JButton addButton, updateButton, deleteButton, viewButton;
    private JTable employeeTable;
    private EmployeeDAO employeeDAO;

    public EmployeeApp() {
        employeeDAO = new EmployeeDAO();

        // Set up the frame
        setTitle("Employee Management");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel for input fields
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        inputPanel.add(new JLabel("ID:"));
        idField = new JTextField();
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Department:"));
        departmentField = new JTextField();
        inputPanel.add(departmentField);
        add(inputPanel, BorderLayout.NORTH);

        // Panel for buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        addButton = new JButton("Add");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
        viewButton = new JButton("View");
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);
        add(buttonPanel, BorderLayout.CENTER);

        // Panel for the table
        JPanel tablePanel = new JPanel(new BorderLayout());
        employeeTable = new JTable();
        tablePanel.add(new JScrollPane(employeeTable), BorderLayout.CENTER);
        tablePanel.setPreferredSize(new Dimension(600, 200));
        add(tablePanel, BorderLayout.SOUTH);

        // Add action listeners to the buttons
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addEmployee();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateEmployee();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteEmployee();
            }
        });

        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewEmployees();
            }
        });

        // Add mouse listener for table row selection
        employeeTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = employeeTable.getSelectedRow();
                if (row != -1) { // Ensure a row is selected
                    idField.setText(employeeTable.getValueAt(row, 0).toString());
                    nameField.setText(employeeTable.getValueAt(row, 1).toString());
                    departmentField.setText(employeeTable.getValueAt(row, 2).toString());
                }
            }
        });

        // Show the frame
        setVisible(true);
    }

    private void addEmployee() {
        int id = Integer.parseInt(idField.getText());
        String name = nameField.getText();
        String department = departmentField.getText();

        if (employeeDAO.insertEmployee(id, name, department)) {
            JOptionPane.showMessageDialog(this, "Employee added successfully!");
            clearFields();
            viewEmployees();
        } else {
            JOptionPane.showMessageDialog(this, "Error adding employee.");
        }
    }

    private void updateEmployee() {
        String idText = idField.getText().trim();
        String name = nameField.getText().trim();
        String department = departmentField.getText().trim();

        if (idText.isEmpty() || name.isEmpty() || department.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return;
        }

        int id;
        try {
            id = Integer.parseInt(idText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid ID format.");
            return;
        }

        if (employeeDAO.updateEmployee(id, name, department)) {
            JOptionPane.showMessageDialog(this, "Employee updated successfully!");
            clearFields();
            viewEmployees();
        } else {
            JOptionPane.showMessageDialog(this, "Error updating employee. Please ensure the ID exists.");
        }
    }

    private void deleteEmployee() {
        String idText = idField.getText().trim();

        if (idText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter an ID.");
            return;
        }

        int id;
        try {
            id = Integer.parseInt(idText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid ID format.");
            return;
        }

        if (employeeDAO.deleteEmployee(id)) {
            JOptionPane.showMessageDialog(this, "Employee deleted successfully!");
            clearFields();
            viewEmployees();
        } else {
            JOptionPane.showMessageDialog(this, "Error deleting employee. Please ensure the ID exists.");
        }
    }

    private void viewEmployees() {
        List<String[]> employees = employeeDAO.getAllEmployees();
        String[] columnNames = {"ID", "Name", "Department"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        for (String[] employee : employees) {
            model.addRow(employee);
        }

        employeeTable.setModel(model);
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        departmentField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EmployeeApp());
    }
}
