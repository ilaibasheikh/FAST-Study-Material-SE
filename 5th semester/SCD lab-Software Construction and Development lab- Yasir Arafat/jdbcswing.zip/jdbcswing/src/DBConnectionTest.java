import java.sql.Connection;
import java.sql.SQLException;

public class DBConnectionTest {
    public static void main(String[] args) {
        // Get the connection from the DBConnection class
        Connection connection = DBConnection.getConnection();

        if (connection != null) {
            System.out.println("Connected to the Oracle database successfully!");

            // Close the connection after the test
            try {
                connection.close();
                System.out.println("Connection closed.");
            } catch (SQLException e) {
                System.out.println("Failed to close the connection.");
                e.printStackTrace();
            }
        } else {
            System.out.println("Failed to connect to the Oracle database.");
        }
    }
}
