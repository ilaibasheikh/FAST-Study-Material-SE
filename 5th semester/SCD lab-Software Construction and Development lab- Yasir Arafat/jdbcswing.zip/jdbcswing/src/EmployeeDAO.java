import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {
    private Connection connection;

    public EmployeeDAO() {
        connection = DBConnection.getConnection();
    }

    // Insert a new employee
    public boolean insertEmployee(int id, String name, String department) {
        String query = "INSERT INTO Employees (ID, Name, Department) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id);
            stmt.setString(2, name);
            stmt.setString(3, department);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Update an existing employee
    public boolean updateEmployee(int id, String name, String department) {
        String query = "UPDATE Employees SET Name = ?, Department = ? WHERE ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, department);
            stmt.setInt(3, id);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete an employee
    public boolean deleteEmployee(int id) {
        String query = "DELETE FROM Employees WHERE ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Fetch all employees
    public List<String[]> getAllEmployees() {
        List<String[]> employees = new ArrayList<>();
        String query = "SELECT * FROM Employees";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                String[] employee = {
                        String.valueOf(rs.getInt("ID")),
                        rs.getString("Name"),
                        rs.getString("Department")
                };
                employees.add(employee);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return employees;
    }
}
