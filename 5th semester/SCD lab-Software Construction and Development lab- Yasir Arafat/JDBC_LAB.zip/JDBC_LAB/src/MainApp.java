import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InsertData insertData = new InsertData();
        UpdateData updateData = new UpdateData();
        DeleteData deleteData = new DeleteData();
        ShowData showData = new ShowData();

        boolean continueRunning = true;

        while (continueRunning) {
            // Display the menu
            System.out.println("Choose an operation:");
            System.out.println("1. Insert Employee");
            System.out.println("2. Update Employee");
            System.out.println("3. Delete Employee");
            System.out.println("4. Show Employees");
            System.out.println("5. Exit");
            System.out.print("Enter your choice (1-5): ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            switch (choice) {
                case 1:
                    System.out.println("id");
                    int u_id = scanner.nextInt();

                    System.out.println("Name");
                    String u_name = scanner.next();

                    System.out.println("Department");
                    String u_department = scanner.next();
                    insertData.insertEmployee(u_id,u_name,u_department);
                    break;
                case 2:
                    System.out.print("Enter the ID of the employee to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline
                    System.out.print("Enter the new name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter the new department: ");
                    String newDepartment = scanner.nextLine();
                    updateData.updateEmployee(updateId, newName, newDepartment);
                    break;
                case 3:
                    System.out.print("Enter the ID of the employee to delete: ");
                    int deleteId = scanner.nextInt();
                    deleteData.deleteEmployee(deleteId);
                    break;
                case 4:
                    showData.displayEmployees();
                    break;
                case 5:
                    continueRunning = false; // Exit the loop
                    break;
                default:
                    System.out.println("Invalid choice! Please enter a number between 1 and 5.");
            }
        }

        System.out.println("Exiting the program. Goodbye!");
        scanner.close();
    }
}
