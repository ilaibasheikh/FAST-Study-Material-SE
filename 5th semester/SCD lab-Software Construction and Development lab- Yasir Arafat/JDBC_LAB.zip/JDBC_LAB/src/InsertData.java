import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertData {
    public void insertEmployee(int u_id, String u_name, String u_department) {



        String sql = "INSERT INTO employees (id, name, department) VALUES (?, ?, ?)";

        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setInt(1, u_id);
            preparedStatement.setString(2, u_name);
            preparedStatement.setString(3, u_department);

            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println(rowsAffected + " row(s) inserted.");
        } catch (SQLException e) {
            System.out.println("Connection or insert failed!");
            e.printStackTrace();
        }
    }
}
