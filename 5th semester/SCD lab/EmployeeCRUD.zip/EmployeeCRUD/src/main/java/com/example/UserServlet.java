package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        try (Connection connection = DatabaseConnection.getConnection()) {
            if ("delete".equals(action)) {
                String u_id = request.getParameter("u_id");
                int id = Integer.parseInt(u_id);

                PreparedStatement stmt = connection.prepareStatement("DELETE FROM users WHERE u_id = ?");
                stmt.setInt(1, id);
                stmt.executeUpdate();
                response.sendRedirect("result.jsp");

            } else if ("update".equals(action)) {
                String u_id = request.getParameter("u_id");
                String u_name = request.getParameter("u_name");
                String u_email = request.getParameter("u_email");
                String u_password = request.getParameter("u_password");
                int id = Integer.parseInt(u_id);

                PreparedStatement stmt = connection.prepareStatement(
                        "UPDATE users SET u_name = ?, u_email = ?, u_password = ? WHERE u_id = ?");
                stmt.setString(1, u_name);
                stmt.setString(2, u_email);
                stmt.setString(3, u_password);
                stmt.setInt(4, id);
                stmt.executeUpdate();
                response.sendRedirect("result.jsp");

            } else {
                // Handle user creation
                String u_id = request.getParameter("u_id");
                String u_name = request.getParameter("u_name");
                String u_email = request.getParameter("u_email");
                String u_password = request.getParameter("u_password");

                // Check for existing ID
                PreparedStatement checkIdStmt = connection.prepareStatement("SELECT COUNT(*) FROM users WHERE u_id = ?");
                checkIdStmt.setInt(1, Integer.parseInt(u_id));
                ResultSet rsId = checkIdStmt.executeQuery();
                rsId.next();
                boolean idExists = rsId.getInt(1) > 0;

                // Check for existing Email
                PreparedStatement checkEmailStmt = connection.prepareStatement("SELECT COUNT(*) FROM users WHERE u_email = ?");
                checkEmailStmt.setString(1, u_email);
                ResultSet rsEmail = checkEmailStmt.executeQuery();
                rsEmail.next();
                boolean emailExists = rsEmail.getInt(1) > 0;

                if (idExists || emailExists) {
                    String errorMessage = "Please use a different ID and email, as they are already used.";
                    request.setAttribute("errorMessage", errorMessage);
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                } else {
                    // Insert new user
                    PreparedStatement stmt = connection.prepareStatement(
                            "INSERT INTO users (u_id, u_name, u_email, u_password) VALUES (?, ?, ?, ?)");
                    stmt.setInt(1, Integer.parseInt(u_id));
                    stmt.setString(2, u_name);
                    stmt.setString(3, u_email);
                    stmt.setString(4, u_password);
                    stmt.executeUpdate();
                    response.sendRedirect("result.jsp");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database error occurred. Please try again.");
            request.getRequestDispatcher("index.jsp").forward(request, response);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Invalid ID format. Please enter a valid number.");
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }
}
