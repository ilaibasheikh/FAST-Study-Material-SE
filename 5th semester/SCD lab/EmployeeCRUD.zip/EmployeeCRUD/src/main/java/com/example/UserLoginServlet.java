package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Cookie;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserLoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(
                     "SELECT * FROM users WHERE u_email = ? AND u_password = ?")) {

            stmt.setString(1, email);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // User is authenticated
                HttpSession session = request.getSession();
                session.setAttribute("userName", rs.getString("u_name")); // Store username in session
                session.setAttribute("userEmail", email); // Store email in session

                // Set a cookie with the user's email
                Cookie emailCookie = new Cookie("userEmail", email);
                emailCookie.setMaxAge(60 * 60 * 24); // 1 day
                response.addCookie(emailCookie);

                response.sendRedirect("UserDashboard.jsp");
            } else {
                // Invalid credentials
                PrintWriter out = response.getWriter();
                out.println("<script>alert('Invalid email or password!'); window.location='userlogin.jsp';</script>");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
