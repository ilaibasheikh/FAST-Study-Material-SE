package com.example;

import java.sql.Connection;
import java.sql.SQLException;

public class TestConnection {
    public static void main(String[] args) {
        try {
            // Test the database connection
            Connection connection = DatabaseConnection.getConnection();
            if (connection != null) {
                System.out.println("Connection Successful!");
                connection.close();  // Close the connection after testing
            }
        } catch (SQLException e) {
            System.out.println("Connection Failed!");
            e.printStackTrace();
        }
    }
}
