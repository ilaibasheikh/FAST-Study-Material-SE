<%@ page import="java.sql.Connection" %>
<%@ page import="com.example.DatabaseConnection" %>
<%@ page import="java.sql.PreparedStatement" %>
<%@ page import="java.sql.ResultSet" %>
<%
  Connection connection = DatabaseConnection.getConnection();
  PreparedStatement stmt = connection.prepareStatement("SELECT * FROM users");
  ResultSet rs = stmt.executeQuery();
%>

<table border="1">
  <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Role</th>
    <th>Actions</th>
  </tr>

  <%
    while (rs.next()) {
  %>
  <tr>
    <td><%= rs.getInt("u_id") %></td>
    <td><%= rs.getString("u_name") %></td>
    <td><%= rs.getString("u_email") %></td>
    <td><%= rs.getString("u_role") %></td>
    <td>
      <form action="edit.jsp" method="get">
        <input type="hidden" name="u_id" value="<%= rs.getInt("u_id") %>">
        <input type="hidden" name="u_name" value="<%= rs.getString("u_name") %>">
        <input type="hidden" name="u_email" value="<%= rs.getString("u_email") %>">
        <button type="submit">Edit</button>
      </form>
      <form action="UserServlet" method="post" style="display:inline;">
        <input type="hidden" name="u_id" value="<%= rs.getInt("u_id") %>">
        <button type="submit" name="action" value="delete">Delete</button>
      </form>
    </td>
  </tr>
  <%
    }
    rs.close();
    stmt.close();
    connection.close();
  %>
</table>
