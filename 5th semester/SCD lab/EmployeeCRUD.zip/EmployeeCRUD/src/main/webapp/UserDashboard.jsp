<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page session="true" %>
<%
    // Check if the user is authenticated by verifying session attributes
    String userName = (String) session.getAttribute("userName");
    String userEmail = (String) session.getAttribute("userEmail");

    if (userName == null || userEmail == null) {
        // If the session attributes are missing, redirect to the login page
        response.sendRedirect("userlogin.jsp");
        return; // Prevent further processing of the page
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
</head>
<body>
<h2>Welcome, <%= userName %>!</h2>
<p><%= userEmail %>!</p>
<h3>User Dashboard</h3>
<p>This is your dashboard. You can manage your profile here.</p>

<form action="LogoutServlet" >
    <input type="submit" value="Logout">
</form>
</body>
</html>
