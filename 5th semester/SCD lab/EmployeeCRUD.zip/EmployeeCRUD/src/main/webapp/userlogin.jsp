<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
  <title>User Login</title>
</head>
<body>
<h2>User Login</h2>
<form action="UserLoginServlet" method="post">
  <label>Email:</label>
  <input type="email" name="email" required><br>
  <label>Password:</label>
  <input type="password" name="password" required><br>
  <input type="submit" value="Login">
</form>
</body>
</html>
