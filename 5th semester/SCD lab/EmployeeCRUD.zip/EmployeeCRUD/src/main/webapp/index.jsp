<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management App</title>
    <script>
        function showError(message) {
            alert(message);
        }
    </script>
</head>
<body>
<h1>Add User</h1>
<form action="UserServlet" method="post">
    <label for="u_id">User ID:</label>
    <input type="number" id="u_id" name="u_id" required>
    <br>
    <label for="u_name">Name:</label>
    <input type="text" id="u_name" name="u_name" required>
    <br>
    <label for="u_email">Email:</label>
    <input type="email" id="u_email" name="u_email" required>
    <br>
    <label for="u_password">Password:</label>
    <input type="password" id="u_password" name="u_password" required>
    <br>

    <br>
    <input type="submit" value="Add User">
</form>
<br>
<a href="result.jsp">See All Users</a>

<%
    String errorMessage = (String) request.getAttribute("errorMessage");
    if (errorMessage != null) {
%>
<script>
    showError("<%= errorMessage %>");
</script>
<%
    }
%>
</body>
</html>
