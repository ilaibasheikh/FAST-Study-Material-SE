<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
  String u_id = request.getParameter("u_id");
  String u_name = request.getParameter("u_name");
  String u_email = request.getParameter("u_email");
%>
<h1>Edit User</h1>
<form action="UserServlet" method="post">
  <input type="hidden" name="u_id" value="<%= u_id %>">
  <label>Name:</label>
  <input type="text" name="u_name" value="<%= u_name != null ? u_name : "" %>" required>
  <br>
  <label>Email:</label>
  <input type="email" name="u_email" value="<%= u_email != null ? u_email : "" %>" required>
  <br>
  <label>Password:</label>
  <input type="password" name="u_password" required>
  <br><br>
  <input type="hidden" name="action" value="update">
  <input type="submit" value="Update User">
</form>
