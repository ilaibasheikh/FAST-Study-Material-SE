

package com.example.servlet;

import jakarta.servlet.*;
        import jakarta.servlet.http.*;
        import java.io.IOException;
import java.io.PrintWriter;

public class DemoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set the response type
        String name = request.getParameter("name");

        // Create a sample 2D array with data
        String[][] studentData = {
                {"ID", "Name", "Score"},
                {"1", "Alice", "85"},
                {"2", "Bob", "90"},
                {"3", "Charlie", "78"}
        };

        // Set the 2D array and the name as request attributes
        request.setAttribute("name", name);
        request.setAttribute("studentData", studentData);

        // Forward the request back to a JSP page
        RequestDispatcher dispatcher = request.getRequestDispatcher("form.jsp");
        dispatcher.forward(request, response);
    }
}
