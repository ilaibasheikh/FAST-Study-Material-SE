package com.example.servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class DataServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Set the retrieved data as request attributes to be accessed in the next page
        request.setAttribute("name", name);
        request.setAttribute("email", email);
        request.setAttribute("password", password);

        // Forward the request to data.html (we'll create this next)
        RequestDispatcher dispatcher = request.getRequestDispatcher("data.jsp");
        dispatcher.forward(request, response);
    }
}
