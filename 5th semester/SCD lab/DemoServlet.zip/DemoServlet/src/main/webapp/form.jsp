<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Page</title>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
        }
    </style>
</head>
<body>
<h1>Welcome, <%= request.getAttribute("name") %>!</h1>

<h2>Student Data:</h2>
<table>
    <thead>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Score</th>
    </tr>
    </thead>
    <tbody>
    <%
        // Get the 2D array from the request attribute
        String[][] studentData = (String[][]) request.getAttribute("studentData");
        if (studentData != null) {
            for (int i = 1; i < studentData.length; i++) {
    %>
    <tr>
        <td><%= studentData[i][0] %></td>
        <td><%= studentData[i][1] %></td>
        <td><%= studentData[i][2] %></td>
    </tr>
    <%
            }
        }
    %>
    </tbody>
</table>
</body>
</html>
