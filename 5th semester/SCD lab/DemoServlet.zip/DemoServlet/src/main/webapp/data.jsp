<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Data</title>
</head>
<body>
<h1>Registration Successful</h1>
<p><strong>Name:</strong> <%= request.getAttribute("name") %></p>
<p><strong>Email:</strong> <%= request.getAttribute("email") %></p>
<p><strong>Password:</strong> <%= request.getAttribute("password") %></p>
</body>
</html>
